Make sure you extract the .zip folder before starting Kronos
Join the discord if you have any other questions https://discord.gg/bwYwNrKpwJ